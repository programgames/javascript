﻿<!-- Projet Tuteuré - Spot WiFi-->
<!-- Exemple d'application. Jeu quiz sur la mesure du temps-->
<?php
$objets=array("anneaudepaysan"=>"Anneau de paysan","astrolabe"=>"Astrolabe","cadranduberger"=>"Cadran du berger","cadransolaire"=>"Cadran solaire","calendrierdespostes"=>"Calendrier des postes","calendriermaya"=>"Calendrier Maya","calendrierperpetuel"=>"Calendrier perpétuel","carotteglace"=>"Carotte de glace","clepsydre"=>"Clepsydre","chronometre"=>"Chronomètre","gnomon"=>"Gnomon","horlogeabougie"=>"Horloge à bougie","horlogeaencens"=>"Horloge à encens","horlogeafoliot"=>"Horloge à foliot","horlogeatomique"=>"Horloge atomique","horlogeparlante"=>"Horloge parlante","montre"=>"Montre","nocturlabe"=>"Nocturlabe","pointeuse"=>"Pointeuse","pouls"=>"Pouls","reveilmatin"=>"Réveil matin","sablier"=>"Sablier");
$aa=scandir(getcwd()."/temps");$data=array();
for($i=0;$i<count($aa);$i++){
	if(strpos($aa[$i],"jpg")!=false){$name=str_replace(".jpg","",$aa[$i]);
	array_push($data,array("type"=>$name,"label"=>$objets[$name],"img"=>"temps/".$aa[$i]));}}
//for($i=0;$i<count($data);$i++){echo $data[$i]["label"]." : <img src='".$data[$i]["img"]."' style='max-width:200px;max-height:200px'>  ";};exit;
$welcome="<br>Bonjour<br>Bienvenue sur notre projet<br><br>";
?>
<!DOCTYPE html>
<html>
	<head>
	<meta charset="utf-8" />
	<title>Quiz-Mesure du temps</title>
	<script language="Javascript">
function DUMP(tableau, max){
	var fonc=function(tableau,name,prof,tabul){if (prof > max) {return name + ' - Max depth\n';}          
        if (typeof(tableau) == 'object') {var enfant=null;var dumpRetour=tabul+name+'\n';  
            tabul += '\t';for(var item in tableau){enfant=tableau[item];  
                if(typeof(enfant)=='object'){dumpRetour+= fonc(enfant, item, prof + 1, tabul);}else{dumpRetour+=""+tabul+item+': '+enfant+'\n';}}}  
        return dumpRetour;}      
    return fonc(tableau,'',0,'')}  	
	
var data = <?php echo json_encode($data); ?>;
var onPlay=false,score=0
var divCadre,divMenu,divBottom,divQuiz,divImages,divAccueil
var quiz,images=""
window.onresize=RESIZE

function INIT(){
	divCadre=document.createElement('div');document.body.appendChild(divCadre);
	divMenu=document.createElement('div');document.body.appendChild(divMenu);
	divBottom=document.createElement('div');document.body.appendChild(divBottom);
	divQuiz=document.createElement('div');document.body.appendChild(divQuiz)
	divSkin=divImages=document.createElement('div');document.body.appendChild(divSkin)
	divImages=document.createElement('div');document.body.appendChild(divImages)
	divAccueil=document.createElement('div');document.body.appendChild(divAccueil)
	divAccueil.innerHTML="<div style='text-align:center;'><?php echo $welcome;?><br><button onclick='PLAY()' style='cursor:pointer;cursor:hand;font-size:25px;font-weight:bold'>Play</button></div>";

	RESIZE()
}
function allowDrop(ev) {
    ev.preventDefault();
}

function drag(ev) {

    ev.dataTransfer.setData("text", ev.target.id);
  
}

function drop(ev) {
	ev.
    ev.preventDefault();
    var da = ev.dataTransfer.getData("text");
    ev.target.appendChild(document.getElementById(da));
}

function afficherTuiles(){
	
    for(i=12-1;i>=0;i--){
        divSkin.innerHTML+="<div ondrop='drop(event)' ondragover='allowDrop(event)' style=' border: 1px solid #aaaaaa; padding: 10px;height: 110px; width: 150px;margin-top:75px;'></div>";
    }

}



function RESIZE(){
	divCadre.style.cssText="position:absolute;top:0%;height:100%;left:0%;width:100%;z-index:0;background-color:#BBBBBB";
	var h=divCadre.offsetHeight	
	divMenu.style.cssText="position:absolute;top:0%;height:25px;left:0%;width:100%;z-index:1;background-color:pink";		
	divBottom.style.cssText="position:absolute;top:"+(h-25)+"px;height:25px;left:0%;width:100%;z-index:2;background-color:pink";	
	divQuiz.style.cssText="position:absolute;top:25px;height:"+(h-50)+"px;left:0%;width:70%;z-index:3;background-color:lightgreen";	
	divSkin.style.cssText="position:absolute;top:25px;height:"+(h-50)+"px;left:0%;width:70%;z-index:4;background-color:black;opacity:0.3;display:flex;flex-flow:row wrap;justify-content:space-around;align-items:flex-start";
	if(!onPlay){divSkin.style.cssText="position:absolute;top:0px;height:100%;left:0%;width:100%;z-index:4;background-color:black;opacity:0.3";}		
	divImages.style.cssText="position:absolute;top:25px;height:"+(h-50)+"px;left:70%;width:30%;z-index:5;user-select :none;background-color:lightblue;display:flex;flex-flow:row wrap;justify-content:space-around;align-items:flex-start";
	divAccueil.style.cssText="position:absolute;top:25%;height:50%;left:25%;width:50%;z-index:-1;background-color:yellow";		
	if(!onPlay){divAccueil.style.zIndex=6}
}


function AFFICHERIMAGES(){
	 
	for(i=12-1;i>=0;i--){
		divImages.innerHTML+="<img id='drag"+i+"' draggable='true' ondragstart='drag(event)' style='max-height: 110px' src='"+data[i]["img"]+"'>";
	}
}

function MELANGE(){
	 for(i=data.length-1;i>=0;i--){
		 var j = Math.floor(i*Math.random());
		 var k=data[j];data[j]=data[i];data[i]=k
	 }
	 
console.log(" data="+DUMP(data,3))	 
 }
function PLAY(){MELANGE();onPlay=true;score=1000;RESIZE();UPDATE_SCORE();AFFICHERIMAGES();afficherTuiles();}

function UPDATE_SCORE(){
	score=score-1
	divBottom.innerHTML="Score="+score+" points"	
	setTimeout(function(){UPDATE_SCORE()},1000)
}



	</script>
	</head>	
	<body></body>
	<script>INIT()</script>
</html>	
